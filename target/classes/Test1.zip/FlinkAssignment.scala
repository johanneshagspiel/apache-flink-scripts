import java.text.SimpleDateFormat
import java.util.Date

import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.co.ProcessJoinFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.api.windowing.assigners.{SlidingEventTimeWindows, TumblingEventTimeWindows}
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.util.Collector
import util.Protocol.{Commit, CommitGeo, CommitSummary, File}
import util.{CommitGeoParser, CommitParser, Protocol}

/** Do NOT rename this class, otherwise autograding will fail. **/
object FlinkAssignment {

  val env = StreamExecutionEnvironment.getExecutionEnvironment

  def main(args: Array[String]): Unit = {

    /**
      * Setups the streaming environment including loading and parsing of the datasets.
      *
      * DO NOT TOUCH!
      */
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    env.setParallelism(1)

    // Read and parses commit stream.
    val commitStream =
      env
        .readTextFile("data/flink_commits.json")
        .map(new CommitParser)

    // Read and parses commit geo stream.
    val commitGeoStream =
      env
        .readTextFile("data/flink_commits_geo.json")
        .map(new CommitGeoParser)

    /** Use the space below to print and test your questions. */
//    dummy_question(commitStream).print()
    question_eight(commitStream, commitGeoStream).print()

    /** Start the streaming environment. **/
    env.execute()
  }

  /** Dummy question which maps each commits to its SHA. */
  def dummy_question(input: DataStream[Commit]): DataStream[String] = {
    input.map(_.sha)
  }

  /**
    * Write a Flink application which outputs the sha of commits with at least 20 additions.
    * Output format: sha
    */
  def question_one(input: DataStream[Commit]): DataStream[String] = {

    val test = input
      .filter(x => (x.stats.get.additions >= 20))
      .map(x => x.sha)

    test
  }

  /**
    * Write a Flink application which outputs the names of the files with more than 30 deletions.
    * Output format:  fileName
    */
  def question_two(input: DataStream[Commit]): DataStream[String] = {

    def helper(files: List[File]): List[(String, Int)] = files match {
      case Nil => Nil
      case x :: tail => ((x.filename.get, x.deletions)) :: helper(tail)
    }

    val test = input
      .flatMap(x => helper(x.files))
      .filter(x => (x._2 > 30))
      .map(x => x._1)

    test
  }

  /**
    * Count the occurrences of Java and Scala files. I.e. files ending with either .scala or .java.
    * Output format: (fileName, #occurences)
    */
  def question_three(input: DataStream[Commit]): DataStream[(String, Int)] = {

    def getFileExtension(input: Commit): List[String] = {
      val tempFiles: List[Protocol.File] = input.files
      getFileExtension2(tempFiles)
    }

    def getFileExtension2(input: List[Protocol.File]): List[String] = input match {
      case Nil => Nil
      case x :: tail => getFileExtension3(x.filename.get) :: getFileExtension2(tail)
    }

    def getFileExtension3(input: String): String = {
      val pattern = """[^\.]*$""".r
      val tempFileType: Option[String] = pattern.findFirstIn(input)
      if (tempFileType.isEmpty) "nothing" else tempFileType.get
    }

    val test = input.
      flatMap(x => getFileExtension(x)).
      filter(x => (x.equals("scala") || x.equals("java"))).
      map(x => (x, 1)).
      keyBy(0).
      sum(1)

    test
  }

  /**
    * Count the total amount of changes for each file status (e.g. modified, removed or added) for the following extensions: .js and .py.
    * Output format: (extension, status, count)
    */
  def question_four(input: DataStream[Commit]): DataStream[(String, String, Int)] = {

    def helperEmpty(input: File): Boolean = {
      if (input.status.isEmpty || input.filename.isEmpty) false else true
    }


//    def helper(commit: Commit): List[(String, String)] = {
//      val files: List[File] =  commit.files
//      val result = helperGetFileLevel(files)
//      result
//    }
//
//    def helperGetFileLevel(files: List[File]): List[(String, String)] = files match {
//      case Nil => Nil
//      case x::tail => (getFileExtension(x.filename.get), x.status.get) :: helperGetFileLevel(tail)
//    }

    def getFileExtension(input: String): String = {
      val pattern = """[^\.]*$""".r
      val tempFileType: Option[String] = pattern.findFirstIn(input)
      if (tempFileType.isEmpty) "nothing" else tempFileType.get
    }

    val test = input.
      flatMap(x => x.files).
      filter(x => helperEmpty(x)).
      map(x => (getFileExtension(x.filename.get), x.status.get)).
      filter(x => (x._1.equals(".js") || x._1.equals(".py"))).
      map(x => (if (x._1.endsWith(".js")) ("js", x._2, 1) else ("py", x._2, 1))).
      keyBy(1,0).
      sum(2)

    test
  }

  /**
    * For every day output the amount of commits. Include the timestamp in the following format dd-MM-yyyy; e.g. (26-06-2019, 4) meaning on the 26th of June 2019 there were 4 commits.
    * Make use of a non-keyed window.
    * Output format: (date, count)
    */
  def question_five(input: DataStream[Commit]): DataStream[(String, Int)] = {

    def helperDate(dateIn: Date): String = {
      val tempTime = new SimpleDateFormat("dd-MM-yyyy")
      val result = tempTime.format(dateIn)
      result
    }

    val test = input.
      assignAscendingTimestamps(x => x.commit.committer.date.getTime).
      map(x => (helperDate(x.commit.committer.date), 1)).
      windowAll(TumblingEventTimeWindows.of(Time.days(1))).
      reduce((x,y) => (x._1, x._2 + y._2))

    test
  }

  /**
    * Consider two types of commits; small commits and large commits whereas small: 0 <= x <= 20 and large: x > 20 where x = total amount of changes.
    * Compute every 12 hours the amount of small and large commits in the last 48 hours.
    * Output format: (type, count)
    */
  def question_six(input: DataStream[Commit]): DataStream[(String, Int)] = {

    def helperClassification(changesTotal: Int): String = {
      if (0 <= changesTotal && changesTotal <= 20) "small" else "large"
    }

    val test = input
      .assignAscendingTimestamps(x => x.commit.committer.date.getTime)
      .map(x => (helperClassification(x.stats.get.total), 1))
      .keyBy(0)
      .window(SlidingEventTimeWindows.of(Time.hours(48), Time.hours(12)))
      .reduce((x,y) => (x._1, x._2 + y._2))

    test
  }

  /**
    * For each repository compute a daily commit summary and output the summaries with more than 20 commits and at most 2 unique committers. The CommitSummary case class is already defined.
    *
    * The fields of this case class:
    *
    * repo: name of the repo.
    * date: use the start of the window in format "dd-MM-yyyy".
    * amountOfCommits: the number of commits on that day for that repository.
    * amountOfCommitters: the amount of unique committers contributing to the repository.
    * totalChanges: the sum of total changes in all commits.
    * topCommitter: the top committer of that day i.e. with the most commits. Note: if there are multiple top committers; create a comma separated string sorted alphabetically e.g. `georgios,jeroen,wouter`
    *
    * Hint: Write your own ProcessWindowFunction.
    * Output format: CommitSummary
    */
  def question_seven(commitStream: DataStream[Commit]): DataStream[CommitSummary] = {

//    class MyProcessWindowFunction extends ProcessWindowFunction[Commit, CommitSummary, String, TimeWindow] {
//
//      def process(key: String, context: Context, input: Iterable[Commit], out: Collector[CommitSummary]): () = {
//
//        var result = CommitSummary(key, context.window.getStart,0,0,0,"")
//
//        for (commit <- input)
//          {
//            val repositoryName = helperGetRepositoryName(element.url)
//            val date = context.window.getStart
//            val totalChanges = commit.stats.get.total
//            val committerName = commit.commit.committer.name
//
//            val result = CommitSummary(repositoryName, helperDate(date), 1, 1, totalChanges, committerName)
//            result
//          }
//
//      }
//    }
//
//    val test2 = commitStream
//      .assignAscendingTimestamps(x => x.commit.committer.date.getTime)
//      .keyBy(_.sha)
//      .windowAll(TumblingEventTimeWindows.of(Time.days(1)))
//      .process(new MyProcessWindowFunction())




    def helperGetRepositoryName(urlIn: String): String = {
      val pattern = """(/repos)(/.*)""".r
      val repositoryNameTemp: Option[String] = pattern.findFirstIn(urlIn)
      val repositoryName = repositoryNameTemp.getOrElse("SomethingWentWrong").substring(7)
      val repositorySplit = repositoryName.split("/")
      val repositoryResult = repositorySplit(1)
      repositoryResult
    }

    def helper(commit: Commit): CommitSummary = {
      val repositoryName = helperGetRepositoryName(commit.url)
      val date = commit.commit.committer.date
      val totalChanges = commit.stats.get.total
      val committerName = commit.commit.committer.name

      val result = CommitSummary(repositoryName, helperDate(date), 1, 1, totalChanges, committerName)
      result
    }

    def helperMostPopular(input: String): String = {
      val test = input.split(", ").toList.groupBy(identity).mapValues(_.size).toSeq.sortBy(_._2)

      val tempPopular = test.head
      var result = tempPopular._1

      for(test1 <- test)
        {
          if (test1._2.equals(tempPopular._2) && !test1._1.equals(tempPopular._1))
            {
                result = result + "," + test1._1
            }
        }
      result
    }

    def helperUniqueContributors(input: String): Int = {
      input.split(", ").toList.distinct.size
    }

    def helperDate(dateIn: Date): String = {
      val tempTime = new SimpleDateFormat("dd-MM-yyyy")
      val result = tempTime.format(dateIn)
      result
    }


    val test = commitStream
      .assignAscendingTimestamps(x => x.commit.committer.date.getTime)
      .map(x => helper(x))
      .keyBy(_.repo)
      .windowAll(TumblingEventTimeWindows.of(Time.days(1)))
      .reduce((x, y) => CommitSummary(x.repo, x.date, x.amountOfCommits + y.amountOfCommits, helperUniqueContributors(x.mostPopularCommitter + ", " + y.mostPopularCommitter), x.totalChanges + y.totalChanges, x.mostPopularCommitter + ", " + y.mostPopularCommitter))
      .map(x => CommitSummary(x.repo, x.date, x.amountOfCommits, x.amountOfCommitters, x.totalChanges, helperMostPopular(x.mostPopularCommitter)))

    test
  }

  /**
    * For this exercise there is another dataset containing CommitGeo events. A CommitGeo event stores the sha of a commit, a date and the continent it was produced in.
    * You can assume that for every commit there is a CommitGeo event arriving within a timeframe of 1 hour before and 30 minutes after the commit.
    * Get the weekly amount of changes for the java files (.java extension) per continent.
    *
    * Hint: Find the correct join to use!
    * Output format: (continent, amount)
    */

  def question_eight(commitStream: DataStream[Commit],geoStream: DataStream[CommitGeo]): DataStream[(String, Int)] = {

    class MyProcessWindowFunction extends ProcessJoinFunction[Protocol.CommitGeo, (String, String, Int), (String, Int)] {

      override def processElement(in1: CommitGeo, in2: (String, String, Int), context: ProcessJoinFunction[CommitGeo, (String, String, Int), (String, Int)]#Context, collector: Collector[(String, Int)]): Unit = {
        collector.collect(in1.continent, in2._3)
      }
    }

    def helper(commit: Commit): List[(String, String, Int)] = {
      val result = helperGetFileLevel(commit.sha, commit.files)
      result
    }

    def helperGetFileLevel(sha: String, files: List[File]): List[(String, String, Int)] = files match {
      case Nil => Nil
      case x::tail => (sha, getFileExtension(x.filename.get), x.changes) :: helperGetFileLevel(sha, tail)
    }

    def getFileExtension(input: String): String = {
      val pattern = """[^\.]*$""".r
      val tempFileType: Option[String] = pattern.findFirstIn(input)
      if (tempFileType.isEmpty) "nothing" else tempFileType.get
    }

    val commitStreamTemp = commitStream
      .assignAscendingTimestamps(x => x.commit.committer.date.getTime)
      .flatMap(x => helper(x))
      .filter(x => (x._2.equals("java")))
      .keyBy(_._1)

    val temp = geoStream
      .assignAscendingTimestamps(x => x.createdAt.getTime)
      .keyBy(_.sha)

    val test = temp
      .intervalJoin(commitStreamTemp)
      .between(Time.hours(-1), Time.minutes(30))
      .process(new MyProcessWindowFunction())
      .keyBy(0)
      .window(TumblingEventTimeWindows.of(Time.days(7)))
      .reduce((x,y) => (x._1, x._2 + y._2))

//        .window(TumblingEventTimeWindows.of(Time.days(7)))
//        .apply((x, y) => (x.continent, 1))
//        .keyBy(0)
//        .reduce((x,y) => (x._1, x._2 + y._2))

    test
  }

  /**
    * Find all files that were added and removed within one day. Output as (repository, filename).
    *
    * Hint: Use the Complex Event Processing library (CEP).
    * Output format: (repository, filename)
    */
  def question_nine(inputStream: DataStream[Commit]): DataStream[(String, String)] = {

    def helper(commit: Commit): List[(String, String, String)] = {
      val result = helperGetFileLevel(helperGetRepositoryName(commit.url), commit.files)
      result
    }

    def helperGetFileLevel(repository: String, files: List[File]): List[(String, String, String)] = files match {
      case Nil => Nil
      case x::tail => (repository, x.filename.get, x.status.get) :: helperGetFileLevel(repository, tail)
    }

    def helperGetRepositoryName(urlIn: String): String = {
      val pattern = """(/repos)(/.*)""".r
      val repositoryNameTemp: Option[String] = pattern.findFirstIn(urlIn)
      val repositoryName = repositoryNameTemp.getOrElse("SomethingWentWrong").substring(7)
      val repositorySplit = repositoryName.split("/")
      val repositoryResult = repositorySplit(0) + "/" + repositorySplit(1)
      repositoryResult
    }

    val test = inputStream
      .assignAscendingTimestamps(x => x.commit.committer.date.getTime)
      .flatMap(x => helper(x))
      .filter(x => (x._3.equals("added") || x._3.equals("removed")))
      .map(x => (x._1, x._2))
      .keyBy(0)
      .window(TumblingEventTimeWindows.of(Time.days(1)))
      .reduce((x,y) => (x._1, x._2 + ", " + y._2))

    test
  }

}
